odoo.define('bi_pos_sales_price_mode.CustomProductScreen', function(require) {
'use strict';
  const { Gui } = require('point_of_sale.Gui');
  const PosComponent = require('point_of_sale.PosComponent');
  const { identifyError } = require('point_of_sale.utils');
  const ProductScreen = require('point_of_sale.ProductScreen');
  const { useListener } = require("@web/core/utils/hooks");
  const Registries = require('point_of_sale.Registries');
  const PaymentScreen = require('point_of_sale.PaymentScreen');
  const PaymentScreenNumpad = require('point_of_sale.PaymentScreenNumpad');
  const NumpadWidget = require('point_of_sale.NumpadWidget');
  const Chrome = require('point_of_sale.Chrome');
  const NumberBuffer = require('point_of_sale.NumberBuffer');

   const CustomProductScreen = (ProductScreen) =>
       class extends ProductScreen {
           setup() {
               super.setup();
           }
            //ar Overriding _clickProduct to set Price mode if the sales price is zero
            async _clickProduct(event) {
            if (!this.currentOrder) {
                this.env.pos.add_new_order();
            }
            const product = event.detail;
            const options = await this._getAddProductOptions(product);
            // Do not add product if options is undefined.
            if (!options) return;
            // Add the product after having the extra information.
            await this._addProduct(product, options);
            NumberBuffer.reset();
            const order = this.env.pos.get_order();
                if (order && order.get_selected_orderline()){
                const selectedLine = order.get_selected_orderline();
                if (selectedLine.price === 0.00){
                    this.env.pos.numpadMode = 'price';
                }
                }
        }

      };
   Registries.Component.extend(ProductScreen, CustomProductScreen);
   return CustomProductScreen;
});
